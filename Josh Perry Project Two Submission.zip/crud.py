#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Fri Jul 26 11:18:53 2024
Updated on Sat Aug 03 07:45 2024

@author: joshuaperry6_snhu
"""

from pymongo import MongoClient

class AnimalShelter:
    """ CRUD operations for Animal collection in MongoDB """
    
    def __init__(self, username, password, host, port, db_name, collection_name):
        # Initialize MongoDB client
        self.client = MongoClient(f'mongodb://{username}:{password}@{host}:{port}/')
        self.database = self.client[db_name]
        self.collection = self.database[collection_name]
        
    def create(self, data):
        """Method to insert a document into the collection"""
        if data:
            try:
                insert_result = self.collection.insert_one(data)
                return insert_result.acknowledged
            except Exception as e:
                print(f"An error occurred while inserting data: {e}")
                return False
        else:
            raise ValueError("Data parameter is empty")
            
    def read(self, query):
        """Method to query documents from the collection"""
        if query is not None: # Allow an empty dictionary to retrieve all documents
            try:
                cursor = self.collection.find(query)
                result = [document for document in cursor]
                return result if result else [] # Ensure an empty list is returned if no documents are found
            except Exception as e:
                print(f"An error occured while reading data: {e}")
                return []
        else:
            raise ValueError("Query parameter is empty")
            
    def update(self, query, update_data):
        """Method to update document(s) in the collection"""
        if query and update_data:
            try:
                update_result = self.collection.update_many(query, {'$set': update_data})
                return update_result.modified_count
            except Exception as e:
                print(f"An error occurred while updating data: {e}")
                return 0
        else:
            raise ValueError("Query and/or update_data parameter is empty")
            
    def delete(self, query):
        """Method to delete document(s) from the collection"""
        if query:
            try:
                delete_result = self.collection.delete_many(query)
                return delete_result.deleted_count
            except Exception as e:
                print(f"An error occurred while deleting data: {e}")
                return 0
        else:
            raise ValueError("Query parameter is empty")
            